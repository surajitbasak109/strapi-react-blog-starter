import ApolloClient from "apollo-boost";

const client = new ApolloClient({
  uri:
    `${process.env.REACT_APP_BACKEND_URL}/graphql` ||
    "http://localhost:1337/graphql",
});

console.log(process.env.REACT_APP_BACKEND_URL);

export default client;
